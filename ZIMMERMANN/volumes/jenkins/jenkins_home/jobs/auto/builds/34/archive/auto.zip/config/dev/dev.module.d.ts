export declare class DevModule {
}
