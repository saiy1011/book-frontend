export {};
//# sourceMappingURL=health.controller.js.map