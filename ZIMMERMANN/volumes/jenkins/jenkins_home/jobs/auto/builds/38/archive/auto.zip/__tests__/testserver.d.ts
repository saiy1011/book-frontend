/// <reference types="node" />
import { type INestApplication } from '@nestjs/common';
import { Agent } from 'node:https';
export declare const loginPath: string;
export declare const refreshPath: string;
export declare const host: string, port: number;
export declare const startServer: () => Promise<INestApplication<any>>;
export declare const shutdownServer: () => Promise<void>;
export declare const httpsAgent: Agent;
