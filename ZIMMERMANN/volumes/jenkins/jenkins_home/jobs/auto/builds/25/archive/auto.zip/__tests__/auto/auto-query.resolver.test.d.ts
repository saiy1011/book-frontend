import { type GraphQLFormattedError } from 'graphql';
export interface GraphQLResponseBody {
    data?: Record<string, any> | null;
    errors?: readonly [GraphQLFormattedError];
}
