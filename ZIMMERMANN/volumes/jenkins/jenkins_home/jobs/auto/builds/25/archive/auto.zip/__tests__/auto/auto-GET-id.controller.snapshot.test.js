import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
const idVorhanden = '1';
describe('GET /rest/:id', () => {
    let client;
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}/rest`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: (status) => status < 500,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Auto zu vorhandener ID', async () => {
        const url = `/${idVorhanden}`;
        const { status, headers, data } = await client.get(url);
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        const selfLink = data._links.self.href;
        expect(selfLink).toMatchSnapshot();
    });
});
//# sourceMappingURL=auto-GET-id.controller.snapshot.test.js.map