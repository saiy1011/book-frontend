export declare class AusstattungDTO {
    readonly bezeichnung: string;
    readonly preis: number;
    readonly verfuegbar: boolean;
}
