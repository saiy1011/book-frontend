import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, loginPath, port, refreshPath, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
const username = 'admin';
const password = 'p';
const passwordFalsch = 'FALSCHES_PASSWORT !!!';
describe('REST-Schnittstelle /login', () => {
    let client;
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}/`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: (status) => status < 500,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Login mit korrektem Passwort', async () => {
        const body = `username=${username}&password=${password}`;
        const { status, data } = await client.post(loginPath, body);
        expect(status).toBe(HttpStatus.OK);
        const { access_token } = data;
        const tokenParts = access_token.split('.');
        expect(tokenParts).toHaveLength(3);
        expect(access_token).toMatch(/^[a-z\d]+\.[a-z\d]+\.[\w-]+$/iu);
    });
    test('Login mit falschem Passwort', async () => {
        const body = `username=${username}&password=${passwordFalsch}`;
        const response = await client.post(loginPath, body);
        expect(response.status).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Login ohne Benutzerkennung', async () => {
        const body = '';
        const response = await client.post(loginPath, body);
        expect(response.status).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Refresh', async () => {
        const loginBody = `username=${username}&password=${password}`;
        const loginResponse = await client.post(loginPath, loginBody);
        const { refresh_token } = loginResponse.data;
        const body = `refresh_token=${refresh_token}`;
        const { status, data } = await client.post(refreshPath, body);
        expect(status).toBe(HttpStatus.OK);
        const { access_token } = data;
        const tokenParts = access_token.split('.');
        expect(tokenParts).toHaveLength(3);
        expect(access_token).toMatch(/^[a-z\d]+\.[a-z\d]+\.[\w-]+$/iu);
    });
});
//# sourceMappingURL=login.controller.test.js.map