import { Ausstattung } from './ausstattung.entity.js';
import { Auto } from './auto.entity.js';
import { Eigentuemer } from './eigentuemer.entity.js';
export const entities = [Ausstattung, Auto, Eigentuemer];
//# sourceMappingURL=entities.js.map