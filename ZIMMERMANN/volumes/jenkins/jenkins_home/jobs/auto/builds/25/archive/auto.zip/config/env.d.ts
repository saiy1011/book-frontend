export declare const env: {
    readonly NODE_ENV: string | undefined;
    readonly CLIENT_SECRET: string | undefined;
    readonly LOG_LEVEL: string | undefined;
    readonly START_DB_SERVER: string | undefined;
};
