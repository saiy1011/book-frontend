export declare class MailModule {
}
