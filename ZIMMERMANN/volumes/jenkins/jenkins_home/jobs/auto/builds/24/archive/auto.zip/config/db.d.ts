export declare const dbType: "postgres" | "mysql" | "sqlite" | "oracle";
