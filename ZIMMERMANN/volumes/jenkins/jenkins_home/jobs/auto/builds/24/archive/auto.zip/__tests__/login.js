import { httpsAgent, loginPath } from './testserver.js';
const usernameDefault = 'admin';
const passwordDefault = 'p';
export const loginRest = async (axiosInstance, username = usernameDefault, password = passwordDefault) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    };
    const response = await axiosInstance.post(loginPath, `username=${username}&password=${password}`, { headers, httpsAgent });
    return response.data.access_token;
};
export const loginGraphQL = async (axiosInstance, username = usernameDefault, password = passwordDefault) => {
    const body = {
        query: `
            mutation {
                login(
                    username: "${username}",
                    password: "${password}"
                ) {
                    access_token
                }
            }
        `,
    };
    const response = await axiosInstance.post('graphql', body, { httpsAgent });
    const data = response.data.data;
    return data.login.access_token;
};
//# sourceMappingURL=login.js.map