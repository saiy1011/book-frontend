import { type AxiosInstance } from 'axios';
export declare const loginRest: (axiosInstance: AxiosInstance, username?: string, password?: string) => Promise<string>;
export declare const loginGraphQL: (axiosInstance: AxiosInstance, username?: string, password?: string) => Promise<string>;
