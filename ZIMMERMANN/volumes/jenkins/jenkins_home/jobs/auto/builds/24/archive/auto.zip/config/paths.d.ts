export declare const paths: {
    readonly rest: "rest";
    readonly auth: "auth";
    readonly login: "login";
    readonly refresh: "refresh";
    readonly swagger: "swagger";
};
