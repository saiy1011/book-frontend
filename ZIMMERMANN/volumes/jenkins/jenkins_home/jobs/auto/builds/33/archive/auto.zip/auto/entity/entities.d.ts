import { Ausstattung } from './ausstattung.entity.js';
import { Auto } from './auto.entity.js';
import { Eigentuemer } from './eigentuemer.entity.js';
export declare const entities: (typeof Ausstattung | typeof Auto | typeof Eigentuemer)[];
