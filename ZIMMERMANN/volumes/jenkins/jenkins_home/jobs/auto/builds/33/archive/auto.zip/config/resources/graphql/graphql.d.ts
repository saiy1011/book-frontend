import { type ApolloDriverConfig } from '@nestjs/apollo';
export declare const graphQlModuleOptions: ApolloDriverConfig;
