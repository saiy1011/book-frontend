import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { AutoReadService } from '../../src/auto/service/auto-read.service.js';
import { HttpStatus } from '@nestjs/common';
import { loginRest } from '../login.js';
const neuesAuto = {
    modellbezeichnung: 'Golf',
    hersteller: 'VOLKSWAGEN',
    fin: '1HGCM82633A123477',
    kilometerstand: 101,
    auslieferungstag: '2022-01-01',
    grundpreis: 250_000.5,
    istAktuellesModell: true,
    getriebeArt: 'MANUELL',
    eigentuemer: {
        eigentuemer: 'Karl Heinz',
        geburtsdatum: '1980-05-15',
        fuehrerscheinnummer: 'HKA321',
    },
    ausstattungen: [
        {
            bezeichnung: 'Sitzheitzung',
            preis: 22.2,
            verfuegbar: true,
        },
    ],
};
const neuesAutoInvalid = {
    modellbezeichnung: '1234jsadklfjsdkfk4jklejlfksdjajsdafjdflded',
    hersteller: '_',
    fin: 'sdfjV',
    kilometerstand: -101,
    auslieferungstag: '2022-02-30',
    grundpreis: -250_000.5,
    istAktuellesModell: true,
    getriebeArt: 'FALSCH',
    eigentuemer: {
        eigentuemer: '1234jsadklfjsdkfk4jklejlfksdjajsdafjdflded',
        geburtsdatum: '2022-02-30',
        fuehrerscheinnummer: '1234jsadklfjsdkfk4jVBSDJSK',
    },
};
const neuesAutoMitExFin = {
    modellbezeichnung: 'Golf',
    hersteller: 'VOLKSWAGEN',
    fin: '1HGCM82633A123456',
    kilometerstand: 101,
    auslieferungstag: '2022-01-01',
    grundpreis: 250_000.5,
    istAktuellesModell: true,
    getriebeArt: 'MANUELL',
    eigentuemer: {
        eigentuemer: 'Karl Heinz',
        geburtsdatum: '1980-05-15',
        fuehrerscheinnummer: 'HKA321',
    },
    ausstattungen: [
        {
            bezeichnung: 'Sitzheitzung',
            preis: 22.2,
            verfuegbar: true,
        },
    ],
};
describe('POST /rest', () => {
    let client;
    const headers = {
        'Content-Type': 'application/json',
    };
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: (status) => status < 500,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Neues Auto', async () => {
        const token = await loginRest(client);
        headers.Authorization = `Bearer ${token}`;
        const response = await client.post('/rest', neuesAuto, { headers });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.CREATED);
        const { location } = response.headers;
        expect(location).toBeDefined();
        const indexLastSlash = location.lastIndexOf('/');
        expect(indexLastSlash).not.toBe(-1);
        const idStr = location.slice(indexLastSlash + 1);
        expect(idStr).toBeDefined();
        expect(AutoReadService.ID_PATTERN.test(idStr)).toBe(true);
        expect(data).toBe('');
    });
    test('Neues Auto mit ungueltigen Daten', async () => {
        const token = await loginRest(client);
        headers.Authorization = `Bearer ${token}`;
        const expectedMsg = [
            expect.stringMatching(/^eigentuemer.eigentuemer /u),
            expect.stringMatching(/^eigentuemer.fuehrerscheinnummer /u),
            expect.stringMatching(/^modellbezeichnung /u),
            expect.stringMatching(/^hersteller /u),
            expect.stringMatching(/^fin /u),
            expect.stringMatching(/^kilometerstand /u),
            expect.stringMatching(/^auslieferungstag /u),
            expect.stringMatching(/^grundpreis /u),
            expect.stringMatching(/^getriebeArt /u),
        ];
        const response = await client.post('/rest', neuesAutoInvalid, { headers });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.UNPROCESSABLE_ENTITY);
        const messages = data.message;
        expect(messages).toBeDefined();
        expect(messages).toHaveLength(expectedMsg.length);
        expect(messages).toEqual(expect.arrayContaining(expectedMsg));
    });
    test('Neues Auto, mit bereits existierender fin', async () => {
        const token = await loginRest(client);
        headers.Authorization = `Bearer ${token}`;
        const response = await client.post('/rest', neuesAutoMitExFin, { headers });
        const { data } = response;
        const { message, statusCode } = data;
        expect(message).toEqual(expect.stringMatching('Es existiert berits ein Auto mit der fin: 1HGCM82633A123456'));
        expect(statusCode).toBe(HttpStatus.UNPROCESSABLE_ENTITY);
    });
    test('Neues Auto nur als "admin"/"fachabteilung', async () => {
        const token = await loginRest(client, 'adriana.alpha', 'p');
        headers.Authorization = `Bearer ${token}`;
        const response = await client.post('/rest', neuesAuto, { headers });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.UNAUTHORIZED);
        expect(data.statusCode).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Neues Auto, aber ohne Token', async () => {
        const response = await client.post('/rest', neuesAuto);
        const { status, data } = response;
        expect(status).toBe(HttpStatus.UNAUTHORIZED);
        expect(data.statusCode).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Neues Auto, aber mit falschem Token', async () => {
        const token = 'FALSCH';
        headers.Authorization = `Bearer ${token}`;
        const response = await client.post('/rest', neuesAuto, { headers });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.UNAUTHORIZED);
        expect(data.statusCode).toBe(HttpStatus.UNAUTHORIZED);
    });
});
//# sourceMappingURL=auto-Post.controller.test.js.map