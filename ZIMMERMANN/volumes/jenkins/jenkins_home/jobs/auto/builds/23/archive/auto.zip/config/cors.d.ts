import { type CorsOptions } from '@nestjs/common/interfaces/external/cors-options.interface.js';
export declare const corsOptions: CorsOptions;
