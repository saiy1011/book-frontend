import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
const eigentuemerVorhanden = 'anna schmidt';
const eigentuemerNichtVorhanden = 'xx';
const modellbezeichnungVorhanden = 'A3';
const modellbezeichnungNichtVorhanden = 'F10';
const herstellerVorhanden = 'DAIMLER';
describe('GET /rest', () => {
    let baseURL;
    let baseURLReg;
    let client;
    beforeAll(async () => {
        await startServer();
        baseURL = `https://${host}:${port}/rest`;
        baseURLReg = `https://${host}:${port}/rest(?:/)+\\d+`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: () => true,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Alle Autos', async () => {
        const response = await client.get('/');
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data).toBeDefined();
        const { autos } = data._embedded;
        autos
            .map((auto) => auto._links.self.href)
            .forEach((selfLink) => {
            expect(selfLink).toMatch(new RegExp(`^${baseURLReg}$`, 'iu'));
        });
    });
    test('Autos mit einem Teil-Eigentuemer suchen', async () => {
        const params = { eigentuemer: eigentuemerVorhanden };
        const response = await client.get('/', {
            params,
        });
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data).toBeDefined();
        const { autos } = data._embedded;
        autos
            .map((auto) => auto.eigentuemer)
            .forEach((eigentuemer) => expect(eigentuemer.eigentuemer.toLowerCase()).toEqual(expect.stringContaining(eigentuemerVorhanden)));
    });
    test('Mind. 1 Auto mit vorhandene Eigentuemer', async () => {
        const params = { eigentuemer: eigentuemerVorhanden };
        const response = await client.get('/', {
            params,
        });
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data).toBeDefined();
        const { autos } = data._embedded;
        autos
            .map((auto) => auto.eigentuemer)
            .forEach((eigentuemer) => expect(eigentuemer.eigentuemer.toLowerCase()).toEqual(expect.stringContaining(eigentuemerVorhanden)));
    });
    test('Autos zu einem nicht vorhandenen Teil-Eigentuemer suchen', async () => {
        const params = { eigentuemer: eigentuemerNichtVorhanden };
        const response = await client.get('/', {
            params,
        });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.NOT_FOUND);
        const { error, statusCode } = data;
        expect(error).toBe('Not Found');
        expect(statusCode).toBe(HttpStatus.NOT_FOUND);
    });
    test('Suche nach Modellbezeichnung A3', async () => {
        const params = { modellbezeichnung: modellbezeichnungVorhanden };
        const response = await client.get('/', {
            params,
        });
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data).toBeDefined();
        const { autos } = data._embedded;
        autos
            .map((auto) => auto.modellbezeichnung)
            .forEach((modellbezeichnung) => expect(modellbezeichnung).toEqual(expect.stringContaining(modellbezeichnungVorhanden)));
    });
    test('Keine Autos zu einer nicht vorhandenen modellbezeichnung', async () => {
        const params = { [modellbezeichnungNichtVorhanden]: 'true' };
        const response = await client.get('/', {
            params,
        });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.NOT_FOUND);
        const { error, statusCode } = data;
        expect(error).toBe('Not Found');
        expect(statusCode).toBe(HttpStatus.NOT_FOUND);
    });
    test('Suche nach Hersteller DAIMLER', async () => {
        const params = { hersteller: herstellerVorhanden };
        const response = await client.get('/', {
            params,
        });
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data).toBeDefined();
        const { autos } = data._embedded;
        autos
            .map((auto) => auto.hersteller)
            .forEach((hersteller) => expect(hersteller).toEqual(expect.stringContaining(herstellerVorhanden)));
    });
    test('Keine Autos zu einer nicht-vorhandenen Property', async () => {
        const params = { foo: 'bar' };
        const response = await client.get('/', {
            params,
        });
        const { status, data } = response;
        expect(status).toBe(HttpStatus.NOT_FOUND);
        const { error, statusCode } = data;
        expect(error).toBe('Not Found');
        expect(statusCode).toBe(HttpStatus.NOT_FOUND);
    });
});
//# sourceMappingURL=auto-GET.controller.test.js.map