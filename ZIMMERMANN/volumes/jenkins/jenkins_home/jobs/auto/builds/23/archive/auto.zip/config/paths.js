export const paths = {
    rest: 'rest',
    auth: 'auth',
    login: 'login',
    refresh: 'refresh',
    swagger: 'swagger',
};
//# sourceMappingURL=paths.js.map