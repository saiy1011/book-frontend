export declare const healthConfig: {
    readonly prettyPrint: boolean;
};
