import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
const idVorhanden = '1';
const idNichtVorhanden = '999999';
const idVorhandenETag = '1';
const idFalsch = 'xy';
describe('GET /rest/:id', () => {
    let client;
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}/rest`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: (status) => status < 500,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Auto zu vorhandener ID', async () => {
        const url = `/${idVorhanden}`;
        const { status, headers, data } = await client.get(url);
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        const selfLink = data._links.self.href;
        expect(selfLink).toMatch(`${url}$`);
    });
    test('Kein Auto zu nicht-vorhandener ID', async () => {
        const url = `/${idNichtVorhanden}`;
        const { status, data } = await client.get(url);
        expect(status).toBe(HttpStatus.NOT_FOUND);
        const { error, message, statusCode } = data;
        expect(error).toBe('Not Found');
        expect(message).toEqual(expect.stringContaining(message));
        expect(statusCode).toBe(HttpStatus.NOT_FOUND);
    });
    test('Kein Auto zu falscher ID', async () => {
        const url = `/${idFalsch}`;
        const { status, data } = await client.get(url);
        expect(status).toBe(HttpStatus.NOT_FOUND);
        expect(data).toBe('Not Found');
        expect(status).toBe(HttpStatus.NOT_FOUND);
    });
    test('Auto zu vorhandener ID mit ETag', async () => {
        const url = `/${idVorhandenETag}`;
        const { status, data } = await client.get(url, {
            headers: { 'If-None-Match': '"0"' },
        });
        expect(status).toBe(HttpStatus.NOT_MODIFIED);
        expect(data).toBe('');
    });
});
//# sourceMappingURL=auto-GET-id.controller.test.js.map