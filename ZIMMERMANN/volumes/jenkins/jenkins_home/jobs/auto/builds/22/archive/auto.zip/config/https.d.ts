import { type HttpsOptions } from '@nestjs/common/interfaces/external/https-options.interface.js';
export declare const httpsOptions: HttpsOptions;
