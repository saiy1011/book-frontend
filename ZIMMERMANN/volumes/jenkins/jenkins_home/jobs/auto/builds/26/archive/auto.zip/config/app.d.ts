export declare const BASEDIR: string;
export declare const RESOURCES_DIR: string;
export declare const config: Record<string, any>;
