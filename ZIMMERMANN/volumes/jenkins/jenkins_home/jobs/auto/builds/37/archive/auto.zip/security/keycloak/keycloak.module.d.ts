export declare class KeycloakModule {
}
