export declare class AutoModule {
}
