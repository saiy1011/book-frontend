import { type OnApplicationBootstrap } from '@nestjs/common';
export declare class BannerService implements OnApplicationBootstrap {
    #private;
    onApplicationBootstrap(): void;
}
