import { GraphQLError } from 'graphql';
export declare class BadUserInputError extends GraphQLError {
    constructor(message: string, exception?: Error);
}
