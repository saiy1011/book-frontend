import { type GraphQLRequest } from '@apollo/server';
export type GraphQLQuery = Pick<GraphQLRequest, 'query'>;
