import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
describe('Login', () => {
    let client;
    const graphqlPath = 'graphql';
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}`;
        client = axios.create({
            baseURL,
            httpsAgent,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Login', async () => {
        const username = 'admin';
        const password = 'p';
        const body = {
            query: `
                mutation {
                    login(
                        username: "${username}",
                        password: "${password}"
                    ) {
                        access_token
                    }
                }
            `,
        };
        const { status, headers, data } = await client.post(graphqlPath, body);
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.errors).toBeUndefined();
        expect(data.data).not.toBeNull();
        expect(data.data.login).not.toBeNull();
        const { login } = data.data;
        expect(login).toBeDefined();
        expect(login).not.toBeNull();
        const { access_token } = login;
        expect(access_token).toBeDefined();
        expect(access_token).not.toBeNull();
        const tokenParts = access_token.split('.');
        expect(tokenParts).toHaveLength(3);
        expect(access_token).toMatch(/^[a-z\d]+\.[a-z\d]+\.[\w-]+$/iu);
    });
    test('Login mit falschem Passwort', async () => {
        const username = 'admin';
        const password = 'FALSCH';
        const body = {
            query: `
                mutation {
                    login(
                        username: "${username}",
                        password: "${password}"
                    ) {
                        access_token
                    }
                }
            `,
        };
        const { status, headers, data } = await client.post(graphqlPath, body);
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.data.login).toBeNull();
        const { errors } = data;
        expect(errors).toBeDefined();
        expect(errors).toHaveLength(1);
        const [error] = errors;
        const { message, path, extensions } = error;
        expect(message).toBe('Falscher Benutzername oder falsches Passwort');
        expect(path).toBeDefined();
        expect(path[0]).toBe('login');
        expect(extensions).toBeDefined();
        expect(extensions.code).toBe('BAD_USER_INPUT');
    });
    test('Refresh', async () => {
        const username = 'admin';
        const password = 'p';
        const loginBody = {
            query: `
                mutation {
                    login(
                        username: "${username}",
                        password: "${password}"
                    ) {
                        refresh_token
                    }
                }
            `,
        };
        const loginResponse = await client.post(graphqlPath, loginBody);
        const { refresh_token } = loginResponse.data.data.login;
        const body = {
            query: `
                mutation {
                    refresh(refresh_token: "${refresh_token}") {
                        access_token
                    }
                }
            `,
        };
        const { status, headers, data } = await client.post(graphqlPath, body);
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.errors).toBeUndefined();
        expect(data.data).not.toBeNull();
        expect(data.data.login).not.toBeNull();
        const { refresh } = data.data;
        expect(refresh).toBeDefined();
        expect(refresh).not.toBeNull();
        const { access_token } = refresh;
        expect(access_token).toBeDefined();
        expect(access_token).not.toBeNull();
        const tokenParts = access_token.split('.');
        expect(tokenParts).toHaveLength(3);
        expect(access_token).toMatch(/^[a-z\d]+\.[a-z\d]+\.[\w-]+$/iu);
    });
});
//# sourceMappingURL=login.resolver.test.js.map