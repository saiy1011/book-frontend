export declare class EigentuemerDTO {
    readonly eigentuemer: string;
    readonly geburtsdatum: Date | string | undefined;
    readonly fuehrerscheinnummer: string | undefined;
}
