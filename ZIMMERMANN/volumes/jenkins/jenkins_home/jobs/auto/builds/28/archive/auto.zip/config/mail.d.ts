import { type Options } from 'nodemailer/lib/smtp-transport';
export declare const options: Options;
export declare const mailConfig: {
    activated: boolean;
    options: Options;
};
