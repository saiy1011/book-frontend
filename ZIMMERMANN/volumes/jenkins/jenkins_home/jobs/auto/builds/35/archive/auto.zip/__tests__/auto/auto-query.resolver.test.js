import { afterAll, beforeAll, describe, expect, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
const idVorhanden = '1';
const eigentuemerVorhanden = 'Max Rimmelspacher';
const teilEigentuemerVorhanden = 'a';
const teilEigentuemerNichtVorhanden = 'abc';
describe('GraphQL Queries', () => {
    let client;
    const graphqlPath = 'graphql';
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}/`;
        client = axios.create({
            baseURL,
            httpsAgent,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Auto zu vorhandener ID', async () => {
        const body = {
            query: `
                {
                    auto(id: "${idVorhanden}") {
                        version
                        fin
                        getriebeArt
                        eigentuemer {
                            eigentuemer
                        }
                    }
                }
            `,
        };
        const response = await client.post(graphqlPath, body);
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.errors).toBeUndefined();
        expect(data.data).toBeDefined();
        const { auto } = data.data;
        const result = auto;
        expect(result.eigentuemer?.eigentuemer).toMatch(/^\w/u);
        expect(result.version).toBeGreaterThan(-1);
        expect(result.id).toBeUndefined();
    });
    test('Auto zu nicht-vorhandener ID', async () => {
        const id = '420';
        const body = {
            query: `
                {
                    auto(id: "${id}") {
                        eigentuemer {
                            eigentuemer
                        }
                    }
                }
            `,
        };
        const response = await client.post(graphqlPath, body);
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.data.auto).toBeNull();
        const { errors } = data;
        expect(errors).toHaveLength(1);
        const [error] = errors;
        const { message, path, extensions } = error;
        expect(message).toBe(`Es gibt kein Auto mit der ID: ${id}.`);
        expect(path).toBeDefined();
        expect(path[0]).toBe('auto');
        expect(extensions).toBeDefined();
        expect(extensions.code).toBe('BAD_USER_INPUT');
    });
    test('Auto zu vorhandenem Eigentuemer', async () => {
        const body = {
            query: `
                query Autos {
    autos(suchkriterien: { eigentuemer: "${eigentuemerVorhanden}" }) {
        getriebeArt
        eigentuemer {
            eigentuemer
        }
    }
}

            `,
        };
        const response = await client.post(graphqlPath, body);
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.errors).toBeUndefined();
        expect(data.data).toBeDefined();
        const { autos } = data.data;
        expect(autos).not.toHaveLength(0);
        const autosArray = autos;
        expect(autosArray).toHaveLength(1);
        const [auto] = autosArray;
        expect(auto.eigentuemer?.eigentuemer).toBe(eigentuemerVorhanden);
    });
    test('Auto zu vorhandenem Teil-Eigentuemer', async () => {
        const body = {
            query: `
                query Autos {
    autos(suchkriterien: { eigentuemer: "${teilEigentuemerVorhanden}" }) {
        getriebeArt
        eigentuemer {
            eigentuemer
        }
    }
}
            `,
        };
        const response = await client.post(graphqlPath, body);
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.errors).toBeUndefined();
        expect(data.data).toBeDefined();
        const { autos } = data.data;
        expect(autos).not.toHaveLength(0);
        const autosArray = autos;
        autosArray
            .map((auto) => auto.eigentuemer)
            .forEach((eigentuemer) => expect(eigentuemer?.eigentuemer.toLowerCase()).toEqual(expect.stringContaining(teilEigentuemerVorhanden)));
    });
    test('Auto zu nicht vorhandenem Eigentuemer', async () => {
        const body = {
            query: `
                query Autos {
    autos(suchkriterien: { eigentuemer: "${teilEigentuemerNichtVorhanden}" }) {
        getriebeArt
        eigentuemer {
            eigentuemer
        }
    }
}
            `,
        };
        const response = await client.post(graphqlPath, body);
        const { status, headers, data } = response;
        expect(status).toBe(HttpStatus.OK);
        expect(headers['content-type']).toMatch(/json/iu);
        expect(data.data.autos).toBeNull();
        const { errors } = data;
        expect(errors).toHaveLength(1);
        const [error] = errors;
        const { message, path, extensions } = error;
        expect(message).toMatch(/^Keine Autos gefunden:/u);
        expect(path).toBeDefined();
        expect(path[0]).toBe('autos');
        expect(extensions).toBeDefined();
        expect(extensions.code).toBe('BAD_USER_INPUT');
    });
});
//# sourceMappingURL=auto-query.resolver.test.js.map