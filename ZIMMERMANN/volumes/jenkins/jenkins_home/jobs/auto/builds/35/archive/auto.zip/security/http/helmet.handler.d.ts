/// <reference types="node" />
export declare const helmetHandlers: ((_req: import("http").IncomingMessage, res: import("http").ServerResponse<import("http").IncomingMessage>, next: () => void) => void)[];
