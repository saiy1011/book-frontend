import { afterAll, beforeAll, describe, test } from '@jest/globals';
import axios from 'axios';
import { host, httpsAgent, port, shutdownServer, startServer, } from '../testserver.js';
import { HttpStatus } from '@nestjs/common';
import { loginRest } from '../login.js';
const id = '6';
describe('DELETE /rest/autos', () => {
    let client;
    beforeAll(async () => {
        await startServer();
        const baseURL = `https://${host}:${port}`;
        client = axios.create({
            baseURL,
            httpsAgent,
            validateStatus: (status) => status < 500,
        });
    });
    afterAll(async () => {
        await shutdownServer();
    });
    test('Vorhandenes Auto loeschen', async () => {
        const url = `/rest/${id}`;
        const token = await loginRest(client);
        const headers = {
            Authorization: `Bearer ${token}`,
        };
        const { status, data } = await client.delete(url, {
            headers,
        });
        expect(status).toBe(HttpStatus.NO_CONTENT);
        expect(data).toBeDefined();
    });
    test('Auto loeschen, aber ohne Token', async () => {
        const url = `/rest/${id}`;
        const response = await client.delete(url);
        expect(response.status).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Auto loeschen, aber mit falschem Token', async () => {
        const url = `/rest/${id}`;
        const token = 'FALSCH';
        const headers = {
            Authorization: `Bearer ${token}`,
        };
        const response = await client.delete(url, { headers });
        expect(response.status).toBe(HttpStatus.UNAUTHORIZED);
    });
    test('Vorhandenes Auto als "user" loeschen', async () => {
        const url = `/rest/60`;
        const token = await loginRest(client, 'user', 'p');
        const headers = {
            Authorization: `Bearer ${token}`,
        };
        const response = await client.delete(url, {
            headers,
        });
        expect(response.status).toBe(HttpStatus.FORBIDDEN);
    });
});
//# sourceMappingURL=auto-DELETE.controller.test.js.map