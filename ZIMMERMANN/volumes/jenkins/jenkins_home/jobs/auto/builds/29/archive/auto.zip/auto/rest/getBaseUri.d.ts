import { type Request } from 'express';
export declare const getBaseUri: (req: Request) => string;
