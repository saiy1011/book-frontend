export declare const dbType: "postgres" | "mysql" | "oracle" | "sqlite";
